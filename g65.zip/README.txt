LTW - GROUP 65
--------------
[up200904082]	Inês Sousa Caldas
[up200901139]	Mariana Owen
[ei11140]	Miguel Lucas


Credentials:
--------------
user: ines.sousacaldas@gmail.com
pwd: 123456c

user: marianaowen1@gmail.com
pwd: 123456b

user: cmiguel.lucas@gmail.com
pwd: 123456a


Notes:
--------------
main page at: /event_ranger/index.php
