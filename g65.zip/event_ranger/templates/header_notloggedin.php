<div id="login_container">
	<form id='loginUser' action='database/session.php' method='post' accept-charset='UTF-8'>
	    <input type='hidden' name='submitted' id='submitted' value='1'/>
	    <label>E-mail:
	    	<input type='email' name='email' id='email'  maxlength="50" />
	    </label>
	    <label>Password:
	    	<input type='password' name='password' id='password' maxlength="50" />
	    </label>
	    <input type='submit' name='Submit' value='Login' />
	</form>
	 <p>Don't have an account? <a href="signup.php">Sign up</a>.</p>
</div>
 
