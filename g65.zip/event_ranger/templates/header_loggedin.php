<nav>
<ul>
	<li><a href="user_page.php">My Page</a></li>
	<li id="btn_logout"><a href="database/session.php?action=logout">Logout</a></li>
</ul>
</nav>

